<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css"
        integrity="sha512-KfkfwYDsLkIlwQp6LFnl8zNdLGxu9YAA1QvwINks4PhcElQSvqcyVLLD9aMhXd13uQjoXtEKNosOWaZqXgel0g=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />

    <title><?php echo $__env->yieldContent('title', env('APP_NAME', 'Bolo')); ?></title>
</head>

<body>
    
    <nav>
        <div>
            <ul class="navbar-left p-1">
                <div class="dropdown">
                    <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton1"
                        data-bs-toggle="dropdown" aria-expanded="false">
                        Menu
                    </button>
                    <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
                        <li>
                            <h6 class="dropdown-header">RECENT ADDS</h6>
                        </li>
                        <li><a class="dropdown-item" href="#">Boogie</a></li>
                        <li><a class="dropdown-item" href="#">Esoteric</a></li>
                        <li><a class="dropdown-item" href="#">House</a></li>
                        <li><a class="dropdown-item" href="#">Pop Music</a></li>
                        <li><a class="dropdown-item" href="#">Tropical</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="<?php echo e(url('about')); ?>">Information</a></li>
                        <li><a class="dropdown-item" href="<?php echo e(url('account')); ?>">Account</a></li>
                        <li><a class="dropdown-item" href="<?php echo e(url('blog')); ?>">Blog</a></li>
                    </ul>
                </div>
            </ul>
            <!--end navbar-left -->
            <ul class="nav navbar-nav text-center d-inline-flex" id="brand-name">
                <li class="nav-item"><a class="nav-link" href="<?php echo e(url('/')); ?>">BOLO RECORDS</a></li>
            </ul>
            <ul class="navbar-right p-1">
                <li class="d-block mb-2"><a href="<?php echo e(url('cart')); ?>" id="cart"><i class="fa fa-shopping-cart"></i>
                        Cart (3)</a></li>
                <li style="cursor: pointer" id="search">
                    <input type="text" id="search-form" placeholder="Search" class="d-inline-block form-control w-auto">
                </li>
            </ul>
            <!--end navbar-right -->
        </div>
        <!--end container -->
    </nav>
    
    <!--end container -->
    <main class="mt-5">
        <?php echo $__env->yieldContent('content'); ?>
        <div class="mx-5 mt-5">
            <footer class="d-flex flex-column flex-wrap justify-content-between my-4 py-3">
                <p class="col-md-4 mb-0 text-muted">Instagram</p>
                <p class="col-md-4 mb-0 text-muted">Mailing List</p>
                <p class="col-md-4 mb-0 text-muted">shop@bolo-records.com</p>
            </footer>
        </div>
    </main>

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
    </script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="<?php echo e(asset('js/main.js')); ?>"></script>

</body>

</html>
<?php /**PATH D:\Personal\projects\upwork\Gondola\Bolo-01\bolo\resources\views/layouts/app.blade.php ENDPATH**/ ?>