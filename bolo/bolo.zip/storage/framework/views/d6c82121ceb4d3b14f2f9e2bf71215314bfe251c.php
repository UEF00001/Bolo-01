
<?php $__env->startSection('content'); ?>
    <div class="row mx-5">
        <div class="col-md-2">
            <?php echo $__env->make('includes.recent-adds', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="col-md-10">
            <h5>Your Account</h5>

            <ul class="nav flex-column">
                <li class="nav-item">
                    <a class="nav-link" href="#">My Orders</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">My Shipping Address</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Methods Of Payment</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Bonus Stuff</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Sign Out</a>
                </li>
            </ul>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Personal\projects\upwork\Gondola\Bolo-01\bolo\resources\views/account.blade.php ENDPATH**/ ?>