
<?php $__env->startSection('content'); ?>
    <div class="row mx-5">
        <div class="col-md-2">
            <?php echo $__env->make('includes.recent-adds', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="col-md-10">
            <div class="d-flex flex-column justify-content-center" id="signin-block">
                <h5 class="mb-3">Sign In</h5>

                <form action="" method="post">
                    <input type="text" class="form-control mb-2" placeholder="Email" name="email">
                    <input type="text" class="form-control mb-2" placeholder="Password" name="password">
                    <div class="d-flex justify-content-between w-100">
                        <a class="nav-link" href="#">Forget Password?</a>
                        <a class="nav-link" href="#">Create Account?</a>
                    </div>
                    <button type="submit" class="btn btn-success">Submit</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Personal\projects\upwork\Gondola\Bolo-01\bolo\resources\views/signin.blade.php ENDPATH**/ ?>