
<?php $__env->startSection('content'); ?>
    <div class="row mx-5">
        <div class="col-md-2">
            <?php echo $__env->make('includes.recent-adds', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="col-md-10">
            <div class="post">
                <span class="d-block mb-1 fw-bold">May 31, 2022: Earth Coincidence Control Office</span>
                <img src="<?php echo e(asset('Assets/Images/pete.png')); ?>" alt="">
                <p>The shop has a placeholder instagram and soundcloud account, but email is the primary avenue of contact.
                    Please just email me with questions, concerns, requests and wantlists.</p>
            </div>
            <div class="post">
                <span class="d-block mb-1 fw-bold">May 28, 2022</span>
                <img src="<?php echo e(asset('Assets/Images/FTivYCbVsAUxSmY.png')); ?>" alt="">
                <p>The shop has a placeholder instagram and soundcloud account, but email is the primary avenue of contact.
                    Please just email me with questions, concerns, requests and wantlists.</p>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Personal\projects\upwork\Gondola\Bolo-01\bolo\resources\views/blog.blade.php ENDPATH**/ ?>