<h3>Related Records</h3>
<div class="row">
    <div class="recent-block pointer-cursor col-md-4 col-sm-6" onclick="location.href='{{ url('get-happy') }}';">
        <img class="img-fluid" src="{{ asset('Assets/Images/R-15793316-1597888782-9556.jpeg.png') }}" alt="">
        <p class="mb-0">Touche-Moi 12” Not 2 Bad Feat.</p>
        <p class="fw-bold">Camile</p>
    </div>
    <div class="recent-block pointer-cursor col-md-4 col-sm-6" onclick="location.href='{{ url('when-she-calls-club-mix') }}';">
        <img class="img-fluid" src="{{ asset('Assets/Images/R-17152054-1611868791-8576.jpeg.png') }}" alt="">
        <p class="mb-0">When She Calls 12”</p>
        <p class="fw-bold">Keith Snipe</p>
    </div>
    <div class="recent-block pointer-cursor col-md-4 col-sm-6" onclick="location.href='{{ url('raw-land') }}';">
        <img class="img-fluid" src="{{ asset('Assets/Images/R-2406404-1366293407-8559.jpeg.png') }}" alt="">
        <p class="mb-0">Make A Show 12”</p>
        <p class="fw-bold">Daina Sutherland</p>
    </div>
</div>